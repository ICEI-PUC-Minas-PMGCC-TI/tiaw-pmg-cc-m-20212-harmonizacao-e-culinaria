import { initializeApp } from "https://www.gstatic.com/firebasejs/9.2.0/firebase-app.js";
import { getFirestore, collection, getDocs } from "https://www.gstatic.com/firebasejs/9.2.0/firebase-firestore.js";

const firebaseConfig = {
    apiKey: "AIzaSyCK098Y94irgI-aXXtX2S2XsOohLrDvHDU",
    authDomain: "pucharmonizacao-4ce7b.firebaseapp.com",
    databaseURL: "https://pucharmonizacao-4ce7b-default-rtdb.firebaseio.com",
    projectId: "pucharmonizacao-4ce7b",
    storageBucket: "pucharmonizacao-4ce7b.appspot.com",
    messagingSenderId: "686841216152",
    appId: "1:686841216152:web:faa17e93db9efaa74fe4ed",
    measurementId: "G-DC36YC9CTS"
};
const app = initializeApp(firebaseConfig);
const db = getFirestore();

var produtos = [];

const cerveja = await getDocs(collection(db, "Cerveja"));
cerveja.forEach((doc) => {
    produtos.push(doc.data());
});

const hidromel = await getDocs(collection(db, "Hidromel"));
hidromel.forEach((doc) => {
    produtos.push(doc.data());
});

const receita = await getDocs(collection(db, "Receita"));
receita.forEach((doc) => {
    produtos.push(doc.data());
});

const rum = await getDocs(collection(db, "Rum"));
rum.forEach((doc) => {
    produtos.push(doc.data());
});

const vinho = await getDocs(collection(db, "Vinho"));
vinho.forEach((doc) => {
    produtos.push(doc.data());
});

const aleatorios = produtos.sort(() => 0.5 - Math.random());
var selecionados = aleatorios.slice(0, 6);

console.log(selecionados);

window.addEventListener('load', geraProdutosCarrosel(), geraProdutosDescricao())

async function geraProdutosCarrosel() {
    let carrosel = document.getElementById("produtosCarrosel");

    carrosel.innerHTML = `
    <div id="carouselExampleControls" class="carousel slide carousel-dark" data-bs-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item active">
            <a id="config"><img src="${selecionados[0].imagem.src}" class="d-block img-fluid"></a>
            <h5 style="text-align: center;">${selecionados[0].nome}</h5>
        </div>
        <div class="carousel-item">
            <a id="config"><img src="${selecionados[1].imagem.src}" class="d-block img-fluid"></a>
            <h5 style="text-align: center;">${selecionados[1].nome}</h5>
        </div>
        <div class="carousel-item">
            <a id="config"><img src="${selecionados[2].imagem.src}" class="d-block img-fluid"></a>
            <h5 style="text-align: center;">${selecionados[2].nome}</h5>
        </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls"
        data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls"
        data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
    </div>
    `
}

async function geraProdutosDescricao() {
    let produtosDescricao = document.getElementById("produtosDescricao")

    produtosDescricao.innerHTML = `
    <hr class="featurette-divider">

        <div class="row featurette">
            <div class="col-md-7">
                <h2 class="featurette-heading">${selecionados[3].nome}</h2>
                <p class="lead">${selecionados[3].descricao}</p>
            </div>
            <div class="col-md-5">
                <img src="${selecionados[3].imagem.src}" class="d-block img-fluid" width="500" height="500">
            </div>
        </div>

        <hr class="featurette-divider">

        <div class="row featurette">
            <div class="col-md-7 order-md-2">
                <h2 class="featurette-heading">${selecionados[4].nome}</h2>
                <p class="lead">${selecionados[4].descricao}</p>
            </div>
            <div class="col-md-5 order-md-1">
                <img src="${selecionados[4].imagem.src}" class="d-block img-fluid" width="500" height="500">
            </div>
        </div>

        <hr class="featurette-divider">

        <div class="row featurette">
            <div class="col-md-7">
                <h2 class="featurette-heading">${selecionados[5].nome}</h2>
                <p class="lead">${selecionados[5].descricao}</p>
            </div>
            <div class="col-md-5">
            <img src="${selecionados[5].imagem.src}" class="d-block img-fluid" width="500" height="500">
            </div>
        </div>

        <hr class="featurette-divider">

    </div>
    `
}