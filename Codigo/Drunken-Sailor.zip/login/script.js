import { initializeApp } from "https://www.gstatic.com/firebasejs/9.2.0/firebase-app.js";
import { getFirestore, getDoc, doc} from "https://www.gstatic.com/firebasejs/9.2.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyCK098Y94irgI-aXXtX2S2XsOohLrDvHDU",
  authDomain: "pucharmonizacao-4ce7b.firebaseapp.com",
  databaseURL: "https://pucharmonizacao-4ce7b-default-rtdb.firebaseio.com",
  projectId: "pucharmonizacao-4ce7b",
  storageBucket: "pucharmonizacao-4ce7b.appspot.com",
  messagingSenderId: "686841216152",
  appId: "1:686841216152:web:faa17e93db9efaa74fe4ed",
  measurementId: "G-DC36YC9CTS"
};
const app = initializeApp(firebaseConfig);
const db = getFirestore();

async function login() {
    let login = document.getElementById("login").value;
    let senha = document.getElementById("senha").value;

    if(login == "" || senha == "") {
        alert("Preencha todos os campos");
    }
    else {
        let docSnap = await getDoc(doc(db, "Usuarios", "Adm"));

        if(docSnap.data().login == login && docSnap.data().senha == senha) {

            sessionStorage.setItem('login', login);
            sessionStorage.setItem('senha', senha);
            window.location.href = "./cadastroProdutos/index.html";
        }
        else {
            alert("Os dados fornecidos estão incorretos!!")
        }
    }
}

document.getElementById("btn-login").addEventListener('click', login);
