import { initializeApp } from "https://www.gstatic.com/firebasejs/9.2.0/firebase-app.js";
import { getFirestore, doc, getDocs, getDoc, collection, addDoc, updateDoc, deleteDoc, orderBy, query, where } from "https://www.gstatic.com/firebasejs/9.2.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyCK098Y94irgI-aXXtX2S2XsOohLrDvHDU",
  authDomain: "pucharmonizacao-4ce7b.firebaseapp.com",
  databaseURL: "https://pucharmonizacao-4ce7b-default-rtdb.firebaseio.com",
  projectId: "pucharmonizacao-4ce7b",
  storageBucket: "pucharmonizacao-4ce7b.appspot.com",
  messagingSenderId: "686841216152",
  appId: "1:686841216152:web:faa17e93db9efaa74fe4ed",
  measurementId: "G-DC36YC9CTS"
};
const app = initializeApp(firebaseConfig);
const db = getFirestore();

const login = sessionStorage.getItem('login');
const senha = sessionStorage.getItem('senha');

window.onload = verificaLogin;

async function verificaLogin() {
    const docSnap = await getDoc(doc(db, "Usuarios", "Adm"));

    if(docSnap.data().login != login || docSnap.data().senha != senha) {
        alert("ERRO! Acesso não autorizado");
        window.location.href = "../../index.html";
    }
    else {
        document.body.style.display = "";
    }
}

var bebida = document.getElementById("formulario").getAttribute("name")

//Função que valida os campos e adiciona o produto ao banco de dados
async function adicionarBebida() {
  let nomeBebida = document.getElementById("nomeBebida").value.toUpperCase();
  let tipoBebida = document.getElementById("tipoBebida").value;
  let regiaoBebida = document.getElementById("regiaoBebida").value;
  let teorBebida = document.getElementById("teorBebida").value;
  let descricaoBebida = document.getElementById("descricaoBebida").value;
  let harmonizacaoBebida = document.getElementById("harmonizacaoBebida").value;
  let imagem = document.getElementById("imagemBebida");
  
  if (nomeBebida == '' || tipoBebida == '' || regiaoBebida == '' || teorBebida == '' || descricaoBebida == '' || harmonizacaoBebida == '' || imagem.value == '') {
    alert("Preencha todos os campos")
  } 
  else {
    let produtoExiste = await carregarDadoEspecifico(nomeBebida)
    console.log(produtoExiste)
    if (!produtoExiste) {
      try {
        const docRef = await addDoc(collection(db, bebida), {
          nome: nomeBebida,
          tipo: tipoBebida,
          regiao: regiaoBebida,
          teor: teorBebida,
          descricao: descricaoBebida,
          harmonizacao: harmonizacaoBebida,
          imagem: {
            nome: filtrarCaminho(imagem.value),
            src: await base64(imagem.files[0])
          }
        });
        limparCampos();
        console.log("Bebida adicionada com ID: ", docRef.id);
        listarBebidas();
      } 
      catch (e) {
        console.error("Error: ", e);
      }
    }
    else {
      alert("Um produto com esse nome já foi cadastrado")
    }
  }
}

//Função que modifica os dados do produto com base no identificador atribuído
async function alterarBebida() {
  let identificador = document.getElementById("idBebida").value
  let nomeBebida = document.getElementById("nomeBebida").value.toUpperCase();
  let tipoBebida = document.getElementById("tipoBebida").value;
  let regiaoBebida = document.getElementById("regiaoBebida").value;
  let teorBebida = document.getElementById("teorBebida").value;
  let descricaoBebida = document.getElementById("descricaoBebida").value;
  let harmonizacaoBebida = document.getElementById("harmonizacaoBebida").value;
  let imagem = document.getElementById("imagemBebida");

  if (nomeBebida == '' || tipoBebida == '' || regiaoBebida == '' || teorBebida == '' || descricaoBebida == '' || harmonizacaoBebida == '' ) {
    alert("Preencha todos os campos")
  } 
  else {
    if(imagem.files.length > 0) {
      await updateDoc(doc(db, bebida, identificador), {
        nome: nomeBebida,
        tipo: tipoBebida,
        regiao: regiaoBebida,
        teor: teorBebida,
        descricao: descricaoBebida,
        harmonizacao: harmonizacaoBebida,
        imagem: {
          nome: filtrarCaminho(imagem.value),
          src: await base64(imagem.files[0])
        }
      })
    }
    else {
      await updateDoc(doc(db, bebida, identificador), {
        nome: nomeBebida,
        tipo: tipoBebida,
        regiao: regiaoBebida,
        teor: teorBebida,
        descricao: descricaoBebida,
        harmonizacao: harmonizacaoBebida
      })
    }
    listarBebidas();
    console.log(`Produto ID: ${identificador} foi alterado`)
    limparCampos();
    document.getElementById("bt-alterar").disabled = true;
    document.getElementById("bt-listar").disabled = false;
    document.getElementById("bt-adicionar").disabled = false;
  }
}

//Função que remove um produto com base no identificador atribuído
async function removerBebida() {
  await deleteDoc(doc(db, bebida, this.parentNode.id));
  listarBebidas();
  console.log(`Arquivo de ID: ${this.parentNode.id} foi deletado`)
}

//Função que faz a requisição dos produtos no banco de dados, formata os resultados e mostra na tela
async function listarBebidas() {
  let identificadores = []
  let dados = document.getElementById('dados');
  var parametroBusca = document.getElementById("parametroBusca").value

  dados.innerHTML = '';

  const querySnapshot = await getDocs(query(collection(db, bebida), orderBy(parametroBusca)));
  querySnapshot.forEach((doc) => {
    
    dados.innerHTML += `
      <p class="listaBebidas" id=${doc.id}>
        <b>${doc.data().nome}</b><br>
        <b>Tipo:</b> ${doc.data().tipo}<br>
        <b>Região:</b> ${doc.data().regiao}<br>
        <b>ABV:</b> ${doc.data().teor}%<br>
        <b>Descrição:</b> ${doc.data().descricao}<br>
        <b>Harmonização:</b> ${doc.data().harmonizacao}<br>
        <img src="${doc.data().imagem.src}" width="100" height="100">
        <button class="bt-remover btn btn-danger">Remover</button> 
        <button class="bt-editar btn btn-warning">Editar</button>
      </p>
      `
    console.log(doc.id, " => ", doc.data());
    identificadores.push(doc.id)
  });
  implementaRemover(identificadores);
  implementaEditar(identificadores);
}

//Função que carrega os dados de um produto com base no identificador atribuído e preenche os campos para edição
async function carregarDados() {
  limparCampos();

  const docRef = doc(db, bebida, this.parentNode.id);
  const docSnap = await getDoc(docRef);

  document.getElementById("bt-listar").disabled = true;
  document.getElementById("bt-adicionar").disabled = true;

  let botoesLista = document.querySelectorAll(".bt-remover")
  botoesLista.forEach((botao) => {
    botao.disabled = true
  })

  document.getElementById("idBebida").value = docSnap.id;
  document.getElementById("nomeBebida").value = docSnap.data().nome;
  document.getElementById("tipoBebida").value = docSnap.data().tipo;
  document.getElementById("regiaoBebida").value = docSnap.data().regiao;
  document.getElementById("teorBebida").value = docSnap.data().teor;
  document.getElementById("descricaoBebida").value = docSnap.data().descricao;
  document.getElementById("harmonizacaoBebida").value = docSnap.data().harmonizacao;
  document.getElementById("nomeImagem").innerHTML = docSnap.data().imagem.nome;
  document.getElementById("bt-alterar").disabled = false;
}

//Função que recebe um valor para usar como filtro e recuperar um produto específico no banco de dados
async function carregarDadoEspecifico(valor) {
  let resultados = []
  const q = query(collection(db, bebida), where("nome", "==", valor))
  const querySnapshot = await getDocs(q);
  querySnapshot.forEach((doc) => {
    resultados.push(doc.data().nome)
  });
  console.log(resultados)
  let existe = resultados.length > 0 ? true : false
  console.log(existe)
  return existe;
}

//Filtra a caminho da img usando regex;
function filtrarCaminho(caminho) {
  return caminho.replace(/.*[\/\\]/, '');
}

//Converte a imagem passada para base64
function base64(imagem) {
  return new Promise((imgBase64) => {
    let reader = new FileReader();
    reader.onload = function () {
      let resultado = reader.result
      return imgBase64(resultado);
    };
    reader.readAsDataURL(imagem);
  })
}

//Função para limpar todos os campos
function limparCampos() {
  let camposInput = document.getElementById("formulario").getElementsByTagName("input")
  let camposText = document.getElementById("formulario").getElementsByTagName("textarea")
  let nomeImagem = document.getElementById("nomeImagem").innerHTML = "Nenhum arquivo escolhido"
  for (let i = 0; i < camposInput.length; i++) {
    camposInput[i].value = '';
  }
  for (let i = 0; i < camposText.length; i++) {
    camposText[i].value = '';
  }
}

//Função para implementar a funcionalidade do botão remover que é gerado no momento da listagem
function implementaRemover(identificadores) {
  for (let i = 0; i < identificadores.length; i++) {
    let bt = document.getElementById(identificadores[i]).getElementsByClassName('bt-remover')
    for (let b = 0; b < bt.length; b++) {
      bt[b].addEventListener('click', removerBebida)
    }
  }
}

//Função para implementar a funcionalidade do botão editar que é gerado no momento da listagem
function implementaEditar(identificadores) {
  for (let i = 0; i < identificadores.length; i++) {
    let bt = document.getElementById(identificadores[i]).getElementsByClassName('bt-editar')
    for (let b = 0; b < bt.length; b++) {
      bt[b].addEventListener('click', carregarDados)
    }
  }
}

//Configuração dos botões
document.getElementById("bt-alterar").disabled = true;
document.getElementById("bt-alterar").addEventListener('click', alterarBebida);
document.getElementById("bt-adicionar").addEventListener('click', adicionarBebida);
document.getElementById("bt-listar").addEventListener('click', listarBebidas);

//Input custom de arquivos
let inputImagem = document.getElementById("imagemBebida");
let nomeImagem = document.getElementById("nomeImagem");
document.getElementById("bt-imagem").addEventListener('click', () => {
  inputImagem.click();
});

inputImagem.addEventListener('change', () => {
  if(inputImagem.value) {
    nomeImagem.innerHTML = filtrarCaminho(inputImagem.value);
  } else {
    nomeImagem.innerHTML = "Nenhum arquivo escolhido"
  }
});