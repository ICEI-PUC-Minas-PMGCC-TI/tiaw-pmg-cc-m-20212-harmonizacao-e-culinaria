import { initializeApp } from "https://www.gstatic.com/firebasejs/9.2.0/firebase-app.js";
import { getFirestore, doc, getDocs, getDoc, collection, addDoc, updateDoc, deleteDoc, orderBy, query, where } from "https://www.gstatic.com/firebasejs/9.2.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyCK098Y94irgI-aXXtX2S2XsOohLrDvHDU",
  authDomain: "pucharmonizacao-4ce7b.firebaseapp.com",
  databaseURL: "https://pucharmonizacao-4ce7b-default-rtdb.firebaseio.com",
  projectId: "pucharmonizacao-4ce7b",
  storageBucket: "pucharmonizacao-4ce7b.appspot.com",
  messagingSenderId: "686841216152",
  appId: "1:686841216152:web:faa17e93db9efaa74fe4ed",
  measurementId: "G-DC36YC9CTS"
};
const app = initializeApp(firebaseConfig);
const db = getFirestore();

const login = sessionStorage.getItem('login');
const senha = sessionStorage.getItem('senha');

window.onload = verificaLogin;

async function verificaLogin() {
    const docSnap = await getDoc(doc(db, "Usuarios", "Adm"));

    if(docSnap.data().login != login || docSnap.data().senha != senha) {
        alert("ERRO! Acesso não autorizado");
        window.location.href = "../../index.html";
    }
    else {
        document.body.style.display = "";
    }
}

var receita = document.getElementById("formulario").getAttribute("name")

//Função que valida os campos e adiciona o produto ao banco de dados
async function adicionarReceita() {
  let nomeReceita = document.getElementById("nomeReceita").value.toUpperCase();
  let descricaoReceita = document.getElementById("descricaoReceita").value;
  let ingredientesReceita = document.getElementById("ingredientesReceita").value;
  let modoPreparoReceita = document.getElementById("modoPreparoReceita").value;
  let harmonizacaoReceita = document.getElementById("harmonizacaoReceita").value;
  let imagem = document.getElementById("imagemReceita");

  if (nomeReceita == '' || descricaoReceita == '' || ingredientesReceita == '' || modoPreparoReceita == '' || harmonizacaoReceita == '' || imagem.value == '') {
    alert("Preencha todos os campos")
  }
  else {
    let produtoExiste = await carregarDadoEspecifico(nomeReceita)
    console.log(produtoExiste)
    if (!produtoExiste) {
      try {
        const docRef = await addDoc(collection(db, receita), {
          nome: nomeReceita,
          descricao: descricaoReceita,
          ingredientes: ingredientesReceita,
          modoPreparo: modoPreparoReceita,
          harmonizacao: harmonizacaoReceita,
          imagem: {
            nome: filtrarCaminho(imagem.value),
            src: await base64(imagem.files[0])
          }
        });
        limparCampos();
        console.log("Receita adicionada com ID: ", docRef.id);
        listarReceitas();
      }
      catch (e) {
        console.error("Error: ", e);
      }
    }
    else {
      alert("Uma receita com esse nome já foi cadastrado")
    }
  }
}

//Função que modifica os dados do produto com base no identificador atribuído
async function alterarReceita() {
  let identificador = document.getElementById("idReceita").value
  let nomeReceita = document.getElementById("nomeReceita").value.toUpperCase();
  let descricaoReceita = document.getElementById("descricaoReceita").value;
  let ingredientesReceita = document.getElementById("ingredientesReceita").value;
  let modoPreparoReceita = document.getElementById("modoPreparoReceita").value;
  let harmonizacaoReceita = document.getElementById("harmonizacaoReceita").value;
  let imagem = document.getElementById("imagemReceita");

  if (nomeReceita == '' || descricaoReceita == '' || ingredientesReceita == '' || modoPreparoReceita == '' || harmonizacaoReceita == '') {
    alert("Preencha todos os campos")
  }
  else {
    if (imagem.files.length > 0) {
      await updateDoc(doc(db, bebida, identificador), {
        nome: nomeReceita,
        descricao: descricaoReceita,
        ingredientes: ingredientesReceita,
        modoPreparo: modoPreparoReceita,
        harmonizacao: harmonizacaoReceita,
        imagem: {
          nome: filtrarCaminho(imagem.value),
          src: await base64(imagem.files[0])
        }
      })
    }
    else {
      await updateDoc(doc(db, receita, identificador), {
        nome: nomeReceita,
        descricao: descricaoReceita,
        ingredientes: ingredientesReceita,
        modoPreparo: modoPreparoReceita,
        harmonizacao: harmonizacaoReceita,
      })
    }
    listarReceitas();
    console.log(`Produto ID: ${identificador} foi alterado`)
    limparCampos();
    document.getElementById("bt-alterar").disabled = true;
    document.getElementById("bt-listar").disabled = false;
    document.getElementById("bt-adicionar").disabled = false;
  }
}

//Função que remove um produto com base no identificador atribuído
async function removerReceita() {
  await deleteDoc(doc(db, receita, this.parentNode.id));
  listarReceitas();
  console.log(`Arquivo de ID: ${this.parentNode.id} foi deletado`)
}

//Função que faz a requisição dos produtos no banco de dados, formata os resultados e mostra na tela
async function listarReceitas() {
  let identificadores = []
  let dados = document.getElementById('dados');

  dados.innerHTML = '';

  const querySnapshot = await getDocs(query(collection(db, receita)));
  querySnapshot.forEach((doc) => {

    dados.innerHTML += `
      <p class="listaReceitas" id=${doc.id}>
        <b>${doc.data().nome}</b><br>
        <b>Descrição:</b> ${doc.data().descricao}<br>
        <b>Ingredientes:</b> ${doc.data().ingredientes}%<br>
        <b>Modo de preparo:</b> ${doc.data().modoPreparo}<br>
        <b>Harmonização:</b> ${doc.data().harmonizacao}<br>
        <img src=${doc.data().imagem.src} width="100" height="100">
        <button class="bt-remover btn btn-danger">Remover</button> 
        <button class="bt-editar btn btn-warning">Editar</button>
      </p>
      `
    console.log(doc.id, " => ", doc.data());
    identificadores.push(doc.id)
  });
  implementaRemover(identificadores);
  implementaEditar(identificadores);
}

//Função que carrega os dados de um produto com base no identificador atribuído e preenche os campos para edição
async function carregarDados() {
  limparCampos();

  const docRef = doc(db, receita, this.parentNode.id);
  const docSnap = await getDoc(docRef);

  document.getElementById("bt-listar").disabled = true;
  document.getElementById("bt-adicionar").disabled = true;

  let botoesLista = document.querySelectorAll(".bt-remover")
  botoesLista.forEach((botao) => {
    botao.disabled = true
  })

  document.getElementById("idBebida").value = docSnap.id;
  document.getElementById("nomeReceita").value = docSnap.data().nome;
  document.getElementById("descricaoReceita").value = docSnap.data().descricao;
  document.getElementById("ingredientesReceita").value = docSnap.data().ingredientes;
  document.getElementById("harmonizacaoReceita").value = docSnap.data().harmonizacao;
  document.getElementById("nomeImagem").innerHTML = docSnap.data().imagem.nome;
  document.getElementById("bt-alterar").disabled = false;
}

//Função que recebe um valor para usar como filtro e recuperar um produto específico no banco de dados
async function carregarDadoEspecifico(valor) {
  let resultados = []
  const q = query(collection(db, receita), where("nome", "==", valor))
  const querySnapshot = await getDocs(q);
  querySnapshot.forEach((doc) => {
    resultados.push(doc.data().nome)
  });
  console.log(resultados)
  let existe = resultados.length > 0 ? true : false
  console.log(existe)
  return existe;
}

//Filtra a caminho da img usando regex;
function filtrarCaminho(caminho) {
  return caminho.replace(/.*[\/\\]/, '');
}

//Converte a imagem passada para base64
function base64(imagem) {
  return new Promise((imgBase64) => {
    let reader = new FileReader();
    reader.onload = function () {
      let resultado = reader.result
      return imgBase64(resultado);
    };
    reader.readAsDataURL(imagem);
  })
}

//Função para limpar todos os campos
function limparCampos() {
  let camposInput = document.getElementById("formulario").getElementsByTagName("input")
  let camposText = document.getElementById("formulario").getElementsByTagName("textarea")
  let nomeImagem = document.getElementById("nomeImagem").innerHTML = "Nenhum arquivo escolhido"
  for (let i = 0; i < camposInput.length; i++) {
    camposInput[i].value = '';
  }
  for (let i = 0; i < camposText.length; i++) {
    camposText[i].value = '';
  }
}

//Função para implementar a funcionalidade do botão remover que é gerado no momento da listagem
function implementaRemover(identificadores) {
  for (let i = 0; i < identificadores.length; i++) {
    let bt = document.getElementById(identificadores[i]).getElementsByClassName('bt-remover')
    for (let b = 0; b < bt.length; b++)
    bt[b].addEventListener('click', removerReceita)
  }
}

//Função para implementar a funcionalidade do botão editar que é gerado no momento da listagem
function implementaEditar(identificadores) {
  for (let i = 0; i < identificadores.length; i++) {
    let bt = document.getElementById(identificadores[i]).getElementsByClassName('bt-editar')
    for (let b = 0; b < bt.length; b++) {
      bt[b].addEventListener('click', carregarDados)
    }
  }
}

//Configuração dos botões
document.getElementById("bt-alterar").disabled = true;
document.getElementById("bt-alterar").addEventListener('click', alterarReceita)
document.getElementById("bt-adicionar").addEventListener('click', adicionarReceita);
document.getElementById("bt-listar").addEventListener('click', listarReceitas);

//Input custom de arquivos
let inputImagem = document.getElementById("imagemReceita");
let nomeImagem = document.getElementById("nomeImagem");
document.getElementById("bt-imagem").addEventListener('click', () => {
  inputImagem.click();
});

inputImagem.addEventListener('change', () => {
  if (inputImagem.value) {
    nomeImagem.innerHTML = filtrarCaminho(inputImagem.value);
  } else {
    nomeImagem.innerHTML = "Nenhum arquivo escolhido"
  }
});