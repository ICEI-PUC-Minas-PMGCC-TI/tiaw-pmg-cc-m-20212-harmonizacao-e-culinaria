import { initializeApp } from "https://www.gstatic.com/firebasejs/9.2.0/firebase-app.js";
import { getFirestore, doc, getDoc } from "https://www.gstatic.com/firebasejs/9.2.0/firebase-firestore.js";
import { geraCabecalho } from "../../cabecalhoProduto.js";

const firebaseConfig = {
  apiKey: "AIzaSyCK098Y94irgI-aXXtX2S2XsOohLrDvHDU",
  authDomain: "pucharmonizacao-4ce7b.firebaseapp.com",
  databaseURL: "https://pucharmonizacao-4ce7b-default-rtdb.firebaseio.com",
  projectId: "pucharmonizacao-4ce7b",
  storageBucket: "pucharmonizacao-4ce7b.appspot.com",
  messagingSenderId: "686841216152",
  appId: "1:686841216152:web:faa17e93db9efaa74fe4ed",
  measurementId: "G-DC36YC9CTS"
};
const app = initializeApp(firebaseConfig);
const db = getFirestore();

const params = new URLSearchParams(document.location.search);
const id = params.get("id");

window.addEventListener('load', geraCabecalho(), produtoEspecifico());

async function produtoEspecifico() {
  let dados = document.getElementById('dados');
  
  dados.innerHTML = '';

  const docRef = doc(db, "Rum", id);
  const docSnap = await getDoc(docRef);
    
  document.title = docSnap.data().nome;

  dados.innerHTML += `
    <div id="central" class="destaque">
      <h1>${docSnap.data().nome}</h1>
    </div>
    <div class="px-4 py-2 my-2 text-center" id="config">
      <img class="d-block mx-auto mb-4" src=${docSnap.data().imagem.src}>
    </div>

    <div id="central">
      <div class="infor" style="background-color: #e49052;">
        <p class="tab"><b class="tab">ABV:</b>${docSnap.data().teor}%</p>
        <p class="tab"><b class="tab">Tipo:</b>${docSnap.data().tipo}</p>
      </div>
      <br>
      <br>
      <h1>Descrição</h1>
      <br>
      <p>${docSnap.data().descricao}</p>
      <br>
      <br>
      <h1>Harmonização</h1>
      <br>
      <p>${docSnap.data().harmonizacao}</p>
    </div>
  `
}