import { initializeApp } from "https://www.gstatic.com/firebasejs/9.2.0/firebase-app.js";
import { getFirestore, getDocs, collection, query} from "https://www.gstatic.com/firebasejs/9.2.0/firebase-firestore.js";
import { geraCabecalho } from "../cabecalhoLista.js";

const firebaseConfig = {
  apiKey: "AIzaSyCK098Y94irgI-aXXtX2S2XsOohLrDvHDU",
  authDomain: "pucharmonizacao-4ce7b.firebaseapp.com",
  databaseURL: "https://pucharmonizacao-4ce7b-default-rtdb.firebaseio.com",
  projectId: "pucharmonizacao-4ce7b",
  storageBucket: "pucharmonizacao-4ce7b.appspot.com",
  messagingSenderId: "686841216152",
  appId: "1:686841216152:web:faa17e93db9efaa74fe4ed",
  measurementId: "G-DC36YC9CTS"
};
const app = initializeApp(firebaseConfig);
const db = getFirestore();

window.addEventListener('load', geraCabecalho(), listarBebidas());

async function listarBebidas() {
    let identificadores = []
    let dados = document.getElementById('dados');
    
    dados.innerHTML = '';
  
    const querySnapshot = await getDocs(query(collection(db, "Hidromel")));
    querySnapshot.forEach((doc) => {
      
    dados.innerHTML += `
    <div class="container my-5">
        <div class="row p-4 pb-0 pe-lg-0 pt-lg-5 align-items-center rounded-3 border shadow-lg">
            <div class="px-4 py-5 my-5 text-center" id="config">
                <div id=${doc.id} class="listaBebidas">
                    <img class="d-block mx-auto mb-4" src="${doc.data().imagem.src}">
                    <h1 class="display-5 fw-bold">${doc.data().nome}</h1>
                    <button type="button" class="btn btn-primary btn-lg px-4 gap-3">Saiba mais</button>
                </div> 
            </div>
        </div>
    </div>
    <div class="b-example-divider"></div>
    `
    identificadores.push(doc.id)
    });
    implementaSaibaMais(identificadores);
}

function implementaSaibaMais(identificadores) {
    for (let i = 0; i < identificadores.length; i++) {
      let bt = document.getElementById(identificadores[i]).getElementsByClassName('btn')
      for (let b = 0; b < bt.length; b++) {
        bt[b].addEventListener('click', geraPaginaBebida)
      }
    }
}

function geraPaginaBebida() {
    let idBebida = this.parentNode.id;
    window.location.href = (`./paginaBebida/Bebida.html?id=${idBebida}`);
}