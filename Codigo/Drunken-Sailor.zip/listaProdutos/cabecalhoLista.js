import { initializeApp } from "https://www.gstatic.com/firebasejs/9.2.0/firebase-app.js";
import { getFirestore, doc, getDoc} from "https://www.gstatic.com/firebasejs/9.2.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyCK098Y94irgI-aXXtX2S2XsOohLrDvHDU",
  authDomain: "pucharmonizacao-4ce7b.firebaseapp.com",
  databaseURL: "https://pucharmonizacao-4ce7b-default-rtdb.firebaseio.com",
  projectId: "pucharmonizacao-4ce7b",
  storageBucket: "pucharmonizacao-4ce7b.appspot.com",
  messagingSenderId: "686841216152",
  appId: "1:686841216152:web:faa17e93db9efaa74fe4ed",
  measurementId: "G-DC36YC9CTS"
};
const app = initializeApp(firebaseConfig);
const db = getFirestore();

export async function geraCabecalho() {
let menu = document.getElementById("menu");

const docRef = doc(db, "Logo", "Logo");
const docSnap = await getDoc(docRef);

document.querySelector("link[rel*='icon']").href = docSnap.data().src;

menu.innerHTML = 
`
<nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
      <div class="container-fluid">
        <div class="minhaDiv">
          <img class="d-block mx-auto mb-4" src=${docSnap.data().src} width="100%" height="100%">
        </div>
        <a class="navbar-brand" href="../../index.html">Drunken Sailor</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse"
          aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
          <ul class="navbar-nav me-auto mb-2 mb-md-0">
            <li class="nav-item">
              <a class="nav-link" href="../Cerveja/index.html">Cerveja</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="../Vinho/index.html">Vinho</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="../Hidromel/index.html">Hidromel</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="../Rum/index.html">Rum</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="../Receitas/index.html">Receitas</a>
            </li>
          </ul>
        </div>
      </div>
</nav>
`
}